1. Commissioning RDS using Terraform Scripts and Executing MYSQL Script using 'Local-Exec' and creating database
2. Commissioning EC2 using Terraform Scripts and Executing Shell Script using 'Local-Exec' and creating HTTP Server
